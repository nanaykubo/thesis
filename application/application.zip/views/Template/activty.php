  <!doctype html>
  <html lang="en">
  <title>Font Style</title>
  <body>
  <h1 style="color:red">This is a heading</h1>
  <div>
  <p style="color:blue">This is a paragraph</p>
  </div>
  <div>
  <p style="color:black">This is a paragraph</p>
  </div>
  </body>
  </html>
